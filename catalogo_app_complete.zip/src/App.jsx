import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

// App_Catalogo_Completo.jsx
// Aplicativo completo de catálogo: grid responsivo, filtros, sidebar, drawer mobile com bounce, pesquisa,
// paginação, export CSV, modo escuro, modal de detalhes e animações nos cards.

export default function App() {
  // Dados iniciais (substitua por fetch/API quando integrar)
  const initialProdutos = [
    { id: "001", nome: "Bolsa Minimal", descricao: "Bolsa em couro sintético, tamanho médio.", quantidade: 12, categoria: "Acessórios", preco: 189.9, disponivel: true, tags:["novo","feminino","tendência"], imagem: "https://via.placeholder.com/600x600?text=Bolsa" },
    { id: "002", nome: "Relógio Clássico", descricao: "Relógio analógico com pulseira em aço.", quantidade: 8, categoria: "Acessórios", preco: 349.0, disponivel: false, tags:["promoção","clássico"], imagem: "https://via.placeholder.com/600x600?text=Relogio" },
    { id: "003", nome: "Camisa Linho", descricao: "Camisa leve em linho com caimento soltinho.", quantidade: 5, categoria: "Vestuário", preco: 129.0, disponivel: true, tags:["básico","leve","verão"], imagem: "https://via.placeholder.com/600x600?text=Camisa" },
    { id: "004", nome: "Tênis Urbano", descricao: "Tênis casual para uso diário.", quantidade: 20, categoria: "Calçados", preco: 259.99, disponivel: true, tags:["urbano","conforto"], imagem: "https://via.placeholder.com/600x600?text=Tenis" },
    { id: "005", nome: "Brinco Geométrico", descricao: "Brinco leve em metal banho ouro.", quantidade: 3, categoria: "Acessórios", preco: 79.9, disponivel: false, tags:["leve","estilo"], imagem: "https://via.placeholder.com/600x600?text=Brinco" },
    { id: "006", nome: "Jaqueta Jeans", descricao: "Jaqueta com lavagem vintage.", quantidade: 7, categoria: "Vestuário", preco: 229.0, disponivel: true, tags:["inverno","casual"], imagem: "https://via.placeholder.com/600x600?text=Jaqueta" },
    { id: "007", nome: "Saia Midi", descricao: "Saia midi fluida, tecido leve.", quantidade: 10, categoria: "Vestuário", preco: 149.5, disponivel: true, tags:["feminino","novo"], imagem: "https://via.placeholder.com/600x600?text=Saia" },
    { id: "008", nome: "Carteira Slim", descricao: "Carteira compacta para cartões.", quantidade: 25, categoria: "Acessórios", preco: 59.9, disponivel: true, tags:["básico","masculino"], imagem: "https://via.placeholder.com/600x600?text=Carteira" }
  ];

  // App state
  const [produtos] = useState(initialProdutos);
  const [query, setQuery] = useState("");
  const [categoria, setCategoria] = useState("Todas");
  const [sort, setSort] = useState("recomendado");
  const [precoMin, setPrecoMin] = useState(0);
  const [precoMax, setPrecoMax] = useState(1000);
  const [disponibilidade, setDisponibilidade] = useState("todas");
  const [tagFiltro, setTagFiltro] = useState("");
  const [selected, setSelected] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dark, setDark] = useState(false);

  // Paginação
  const [page, setPage] = useState(1);
  const perPage = 6;

  // Derived lists
  const categorias = useMemo(() => ["Todas", ...Array.from(new Set(produtos.map(p => p.categoria)))], [produtos]);
  const todasTags = useMemo(() => Array.from(new Set(produtos.flatMap(p => p.tags))), [produtos]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = produtos.filter(p => {
      const matchQuery = !q || p.nome.toLowerCase().includes(q) || p.descricao.toLowerCase().includes(q) || p.id.includes(q);
      const matchCategoria = categoria === "Todas" || p.categoria === categoria;
      const matchPreco = p.preco >= precoMin && p.preco <= precoMax;
      const matchDisponibilidade = disponibilidade === "todas" || (disponibilidade === "disponivel" && p.disponivel) || (disponibilidade === "indisponivel" && !p.disponivel);
      const matchTag = !tagFiltro || p.tags.includes(tagFiltro);
      return matchQuery && matchCategoria && matchPreco && matchDisponibilidade && matchTag;
    });

    if (sort === "menor") list = list.slice().sort((a,b)=>a.quantidade-b.quantidade);
    if (sort === "maior") list = list.slice().sort((a,b)=>b.quantidade-a.quantidade);
    if (sort === "nome") list = list.slice().sort((a,b)=>a.nome.localeCompare(b.nome));
    if (sort === "preco") list = list.slice().sort((a,b)=>a.preco-b.preco);

    return list;
  }, [produtos, query, categoria, sort, precoMin, precoMax, disponibilidade, tagFiltro]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  useEffect(()=>{ if (page > totalPages) setPage(1); }, [totalPages]);

  const pageItems = useMemo(()=> filtered.slice((page-1)*perPage, page*perPage), [filtered, page]);

  function exportCSV(items) {
    const header = ["Código","Nome","Descrição","Categoria","Quantidade","Preço","Disponível"];
    const rows = items.map(p=>[p.id,p.nome,p.descricao,p.categoria,p.quantidade,p.preco,p.disponivel ? 'Sim' : 'Não']);
    const csv = [header, ...rows].map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(",")).join('\\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'catalogo_export.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  // UI helpers
  const bounceMotion = {
    initial: { x: -300, opacity: 0 },
    animate: { x: 0, opacity: 1, transition: { type: 'spring', stiffness: 180, damping: 18, mass: 0.7 }},
    exit: { x: -300, opacity: 0, transition: { type: 'spring', stiffness: 180, damping: 20 }}
  };

  return (
    <div className={"min-h-screen " + (dark? 'bg-gray-900 text-gray-100':'bg-white text-gray-900')}>
      <div className="max-w-7xl mx-auto p-6 lg:flex lg:gap-6">

        {/* Mobile: botão para abrir filtros */}
        <div className="lg:hidden mb-4 w-full">
          <div className="flex items-center justify-between gap-2">
            <button onClick={()=>setMobileOpen(true)} className="px-4 py-2 rounded-xl border">Filtros</button>
            <div className="flex items-center gap-2">
              <button onClick={()=>exportCSV(filtered)} className="px-3 py-2 border rounded-xl text-sm">Exportar</button>
              <button onClick={()=>setDark(d=>!d)} className="px-3 py-2 border rounded-xl text-sm">{dark? 'Claro':'Escuro'}</button>
            </div>
          </div>
        </div>

        {/* Drawer mobile com bounce */}
        <AnimatePresence>
          {mobileOpen && (
            <div className="fixed inset-0 z-50 flex lg:hidden">
              <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={()=>setMobileOpen(false)} />

              <motion.aside className="relative bg-white dark:bg-gray-800 w-72 h-full p-4 shadow-2xl z-10 overflow-y-auto rounded-r-2xl" {...bounceMotion}>
                <h3 className="text-lg font-semibold mb-4">Filtros</h3>
                <div className="flex flex-col gap-3">
                  <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Pesquisar" className="border rounded-xl px-4 py-2 w-full" />
                  <select value={categoria} onChange={(e)=>setCategoria(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
                    {categorias.map(c=> <option key={c} value={c}>{c}</option>)}
                  </select>
                  <select value={disponibilidade} onChange={(e)=>setDisponibilidade(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
                    <option value="todas">Todas</option>
                    <option value="disponivel">Disponível</option>
                    <option value="indisponivel">Indisponível</option>
                  </select>
                  <select value={tagFiltro} onChange={(e)=>setTagFiltro(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
                    <option value="">Todas as tags</option>
                    {todasTags.map(tag => <option key={tag} value={tag}>{tag}</option>)}
                  </select>

                  <div className="flex gap-2">
                    <input type="number" value={precoMin} onChange={(e)=>setPrecoMin(Number(e.target.value))} className="border rounded-xl px-3 py-2 w-full" placeholder="R$ min" />
                    <input type="number" value={precoMax} onChange={(e)=>setPrecoMax(Number(e.target.value))} className="border rounded-xl px-3 py-2 w-full" placeholder="R$ max" />
                  </div>

                  <select value={sort} onChange={(e)=>setSort(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
                    <option value="recomendado">Recomendado</option>
                    <option value="menor">Qtd menor</option>
                    <option value="maior">Qtd maior</option>
                    <option value="nome">Nome A-Z</option>
                    <option value="preco">Preço</option>
                  </select>

                  <div className="flex gap-2 mt-2">
                    <button onClick={()=>{ setQuery(''); setCategoria('Todas'); setPrecoMin(0); setPrecoMax(1000); setDisponibilidade('todas'); setTagFiltro(''); setSort('recomendado'); }} className="px-3 py-2 border rounded-xl w-full">Limpar</button>
                    <button onClick={()=>setMobileOpen(false)} className="px-3 py-2 bg-black text-white rounded-xl w-full">Aplicar</button>
                  </div>
                </div>
              </motion.aside>
            </div>
          )}
        </AnimatePresence>

        {/* Sidebar (desktop) */}
        <aside className="hidden lg:block w-72 bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl shadow-sm h-fit sticky top-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Filtros</h3>
            <button onClick={()=>setDark(d=>!d)} className="text-sm px-2 py-1 border rounded">{dark? 'Claro':'Escuro'}</button>
          </div>

          <div className="flex flex-col gap-3">
            <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Pesquisar" className="border rounded-xl px-4 py-2 w-full" />
            <select value={categoria} onChange={(e)=>setCategoria(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
              {categorias.map(c=> <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={disponibilidade} onChange={(e)=>setDisponibilidade(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
              <option value="todas">Todas</option>
              <option value="disponivel">Disponível</option>
              <option value="indisponivel">Indisponível</option>
            </select>
            <label className="text-sm">Tags</label>
            <div className="flex flex-wrap gap-2">
              {todasTags.map(tag => (
                <button key={tag} onClick={()=>setTagFiltro(tagFiltro===tag?'':tag)} className={"px-3 py-1 rounded-full border text-sm " + (tagFiltro===tag? 'bg-black text-white':'')}>{tag}</button>
              ))}
            </div>

            <label className="text-sm">Preço (R$)</label>
            <div className="flex gap-2">
              <input type="number" value={precoMin} onChange={(e)=>setPrecoMin(Number(e.target.value))} className="border rounded-xl px-3 py-2 w-full" />
              <input type="number" value={precoMax} onChange={(e)=>setPrecoMax(Number(e.target.value))} className="border rounded-xl px-3 py-2 w-full" />
            </div>

            <select value={sort} onChange={(e)=>setSort(e.target.value)} className="border rounded-xl px-3 py-2 w-full">
              <option value="recomendado">Recomendado</option>
              <option value="menor">Qtd menor</option>
              <option value="maior">Qtd maior</option>
              <option value="nome">Nome A-Z</option>
              <option value="preco">Preço</option>
            </select>

            <div className="flex gap-2 mt-2">
              <button onClick={()=>{ setQuery(''); setCategoria('Todas'); setPrecoMin(0); setPrecoMax(1000); setDisponibilidade('todas'); setTagFiltro(''); setSort('recomendado'); }} className="px-3 py-2 border rounded-xl w-full">Limpar</button>
              <button onClick={()=>exportCSV(filtered)} className="px-3 py-2 bg-black text-white rounded-xl w-full">Exportar CSV</button>
            </div>

            <p className="text-sm text-gray-500 mt-4">Resultados: <strong>{filtered.length}</strong></p>
          </div>
        </aside>

        {/* Conteúdo principal */}
        <main className="flex-1">
          <header className="flex items-center justify-between mb-6 gap-4">
            <div>
              <h1 className="text-2xl font-semibold">Catálogo de Produtos</h1>
              <p className="text-sm text-gray-500">Grid responsivo para divulgação publicitária.</p>
            </div>

            <div className="hidden sm:flex items-center gap-3">
              <button onClick={()=>exportCSV(filtered)} className="px-3 py-2 border rounded-xl text-sm">Exportar</button>
              <div className="text-sm">Página {page} / {totalPages}</div>
            </div>
          </header>

          <section>
            <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              <AnimatePresence>
                {pageItems.map(prod => (
                  <motion.article key={prod.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y:0 }} exit={{ opacity: 0, y: 8 }} className={"bg-gray-50 dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition cursor-pointer"} onClick={()=>setSelected(prod)}>
                    <div className="relative">
                      <img src={prod.imagem} alt={prod.nome} className="w-full h-56 object-cover" loading="lazy" />
                      <span className="absolute top-3 left-3 bg-white/80 backdrop-blur px-3 py-1 rounded-full text-sm font-medium">{prod.categoria}</span>
                      <span className="absolute top-3 right-3 px-3 py-1 rounded-full text-sm font-semibold bg-black/80 text-white">R$ {prod.preco.toFixed(2)}</span>
                    </div>

                    <div className="p-4">
                      <h2 className="text-lg font-semibold">{prod.nome}</h2>
                      <p className="text-xs text-gray-500 mt-1">Código: <span className="font-medium">{prod.id}</span></p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mt-3 line-clamp-3">{prod.descricao}</p>

                      <div className="flex justify-between items-center mt-4">
                        <span className={`text-sm font-medium ${prod.disponivel ? "text-green-600" : "text-red-600"}`}>
                          {prod.disponivel ? "Disponível" : "Indisponível"}
                        </span>
                        <div className="flex items-center gap-2">
                          <button onClick={(e)=>{ e.stopPropagation(); setSelected(prod); }} className="text-sm px-3 py-1 rounded-full border">Ver</button>
                          <button onClick={(e)=>{ e.stopPropagation(); alert('Criar anúncio — integrar com sistema de anúncios.'); }} className="text-sm px-3 py-1 rounded-full bg-black text-white">Anunciar</button>
                        </div>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </AnimatePresence>
            </div>

            {filtered.length === 0 && (
              <div className="col-span-full text-center py-12 text-gray-500">Nenhum produto encontrado.</div>
            )}
          </section>

          {/* Paginação */}
          <footer className="mt-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button onClick={()=>setPage(p=>Math.max(1,p-1))} className="px-3 py-2 border rounded">Anterior</button>
              <button onClick={()=>setPage(p=>Math.min(totalPages,p+1))} className="px-3 py-2 border rounded">Próxima</button>
            </div>

            <div>
              <select value={perPage} onChange={()=>{}} className="border rounded px-2 py-1 text-sm" disabled>
                <option>{perPage} por página</option>
              </select>
            </div>
          </footer>
        </main>
      </div>

      {/* Modal de detalhes */}
      <AnimatePresence>
        {selected && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-black/40" onClick={()=>setSelected(null)} />

            <motion.div initial={{ scale: 0.98, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.98, opacity: 0 }} transition={{ duration: 0.2 }} className="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-3xl p-6 z-10">
              <div className="flex gap-6">
                <img src={selected.imagem} alt={selected.nome} className="w-56 h-56 object-cover rounded-xl" />
                <div className="flex-1">
                  <h3 className="text-2xl font-semibold">{selected.nome}</h3>
                  <p className="text-sm text-gray-500 mt-1">Código: {selected.id}</p>
                  <p className="mt-4 text-gray-700 dark:text-gray-300">{selected.descricao}</p>
                  <p className="mt-4 font-medium">Preço: R$ {selected.preco.toFixed(2)}</p>
                  <p className="mt-2 text-sm {selected.disponivel ? 'text-green-600':'text-red-600'}">{selected.disponivel ? 'Disponível' : 'Indisponível'}</p>

                  <div className="mt-6 flex items-center gap-4">
                    <button onClick={()=>alert('Criar anúncio — integrar com sistema de anúncios.')} className="px-4 py-2 rounded-xl bg-black text-white">Criar anúncio</button>
                    <button onClick={()=>setSelected(null)} className="px-4 py-2 rounded-xl border">Fechar</button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
