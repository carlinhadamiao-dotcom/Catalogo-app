# Catálogo App - Protótipo Completo

Este é um protótipo React do seu aplicativo de catálogo, com:
- Grid responsivo
- Filtros (categoria, tags, preço, disponibilidade)
- Sidebar desktop e drawer mobile com animação bounce (Framer Motion)
- Modal de detalhes
- Export CSV e paginação

## Como rodar localmente

1. Instale dependências:
   ```bash
   npm install
   ```
2. Rode em modo de desenvolvimento:
   ```bash
   npm run start
   ```

> Observação: o projeto usa classes Tailwind no código original. Para o protótipo rápido incluí um `styles.css` simples. Para visual final, configure Tailwind CSS conforme preferir.

