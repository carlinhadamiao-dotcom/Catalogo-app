import React from 'react';

export default function App() {
  return <div>Projeto base criado. Cole aqui seu componente completo.</div>;
}
